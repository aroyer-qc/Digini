//-------------------------------------------------------------------------------------------------
//
//  File : lib_class_STM32H5_dma.cpp
//
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
// Include file(s)
//-------------------------------------------------------------------------------------------------

#define DMA_DRIVER_GLOBAL
#include "lib_BSP_H5.h"
#include <cstring>
#undef  DMA_DRIVER_GLOBAL

//-------------------------------------------------------------------------------------------------
//
//  Function:       Initialize
//
//  Parameter(s):   DMA_Info_t*         pInfo
//  Return:         None
//
//  Description:    Initialize the DMA object
//
//  Note(s):        Add in direction support for M2M
//
//-------------------------------------------------------------------------------------------------
void DMA_Driver::Initialize(DMA_Info_t* pInfo)
{
    uint32_t Register = 0;

    m_pChannel       = pInfo->pChannel;
    m_Flag           = pInfo->Flag;
    m_IRQn_Channel   = pInfo->IRQn_Channel;
    m_Direction      = pInfo->Direction;
    m_PreempPrio     = pInfo->PreempPrio;
    EnableClock();

    // Reset Linked-List temporary array
    memset(m_NodeInfo.LLRegisters, 0, sizeof(m_NodeInfo.LLRegisters));

    m_pChannel->CCR  = pInfo->Priority;

    switch(pInfo->Direction) // See. "en.stm32h5-system-dma-overview-dmaovw.pdf" from ST Microelectronics, a copy exist in infra/docs
    {
        case BSP_DMA_PERIPHERAL_TO_MEMORY:  Register = (BSP_DMA_SOURCE_ALLOCATED_PORT1 | BSP_DMA_DESTINATION_ALLOCATED_PORT0); break;
        case BSP_DMA_MEMORY_TO_PERIPHERAL:  Register = (BSP_DMA_SOURCE_ALLOCATED_PORT0 | BSP_DMA_DESTINATION_ALLOCATED_PORT1); break;
        case BSP_DMA_MEMORY_TO_MEMORY:      Register = (BSP_DMA_SOURCE_ALLOCATED_PORT1 | BSP_DMA_DESTINATION_ALLOCATED_PORT1); break;
        default:                            ASSERT(0);
    }

    // We only support transfers of identical size (i.e. source data width == destination data width)
    // The transfer size in the CBR1 register must be the number of bytes to transfer (i.e. number of elements * size of each element)
    switch(pInfo->SrcAndDestDataWidth)
    {
        case BSP_DMA_TRANFER_DATA_SIZE_8_BITS:  m_DataWidthShift = 0; break;
        case BSP_DMA_TRANFER_DATA_SIZE_16_BITS: m_DataWidthShift = 1; break;
        case BSP_DMA_TRANFER_DATA_SIZE_32_BITS: m_DataWidthShift = 2; break;
        default:                            ASSERT(0);
    }

    Register |= (pInfo->SrcAndDestIncrement                                  |
                 pInfo->SrcAndDestDataWidth                                  |
                 ((pInfo->SourceBurstLength - 1) << DMA_CTR1_DBL_1_Pos)      |
                 ((pInfo->DestinationBurstLength - 1) << DMA_CTR1_DBL_1_Pos));

    m_NodeInfo.LLRegisters[DMA_NODE_CTR1_IDX] = Register;
    m_NodeInfo.LLRegisters[DMA_NODE_CTR2_IDX] = (pInfo->Request              |
                                                 pInfo->BlockHardwareRequest |
                                                 pInfo->TransferEventMode    |
                                                 pInfo->Direction            |
                                                 pInfo->Mode);
}

//-------------------------------------------------------------------------------------------------
//
//  Function:       SetTransfer
//
//  Parameter(s):   Source
//                  Destination
//                  Length
//  Return:         None
//
//  Description:    Setup transfer from source to destination. according to configuration
//
//  Note(s):        Add in direction support for M2M
//
//-------------------------------------------------------------------------------------------------
void DMA_Driver::SetTransfer(void* pSource, void* pDestination, size_t Length)
{
    SetSource(pSource);
    SetDestination(pDestination);
    SetLength(Length);

    // Once transfer has been configured, we can write all the transfer registers
    WriteTransferRegisters();
}

//-------------------------------------------------------------------------------------------------
//
//  Function:       WriteTransferRegisters
//
//  Parameter(s):   None
//  Return:         None
//
//  Description:    Write registers according to transfer configuration (i.e. transfer must already be configured)
//
//  Note(s):        This only supports a circular mode (when enabled) with one single node
//
//-------------------------------------------------------------------------------------------------
void DMA_Driver::WriteTransferRegisters(void)
{
    uint32_t *pLinkedListNode;

    m_pChannel->CTR1 = m_NodeInfo.LLRegisters[DMA_NODE_CTR1_IDX];
    m_pChannel->CTR2 = m_NodeInfo.LLRegisters[DMA_NODE_CTR2_IDX];
    m_pChannel->CBR1 = m_NodeInfo.LLRegisters[DMA_NODE_CBR1_IDX];
    m_pChannel->CSAR = m_NodeInfo.LLRegisters[DMA_NODE_CSAR_IDX];
    m_pChannel->CDAR = m_NodeInfo.LLRegisters[DMA_NODE_CDAR_IDX];

    if(m_IsCircular == false)
    {
        m_pChannel->CLBAR = 0;
        m_pChannel->CLLR = 0;
    }
    else
    {
        pLinkedListNode = &m_NodeInfo.LLRegisters[0];
        m_NodeInfo.LLRegisters[DMA_NODE_CLLR_IDX] = (uint32_t(pLinkedListNode) & BSP_DMA_LINKED_LIST_ADDRESS_OFFSET_MASK) |
                            BSP_DMA_LINKED_LIST_CTR1_UPDATE |
                            BSP_DMA_LINKED_LIST_CTR2_UPDATE |
                            BSP_DMA_LINKED_LIST_CBR1_UPDATE |
                            BSP_DMA_LINKED_LIST_CSAR_UPDATE |
                            BSP_DMA_LINKED_LIST_CDAR_UPDATE;

        // Configure the linked list registers
        m_pChannel->CLLR =  m_NodeInfo.LLRegisters[DMA_NODE_CLLR_IDX];
        m_pChannel->CLBAR = (uint32_t(pLinkedListNode) & BSP_DMA_LINKED_LIST_BASE_ADDRESS_MASK);
    }
}

//-------------------------------------------------------------------------------------------------
//
//  Function:       CheckFlag
//
//  Parameter(s):   Flag        Flag to check
//  Return:         bool        If true then flag is set.
//
//  Description:    Check flag for specific DMA stream.
//-------------------------------------------------------------------------------------------------
bool DMA_Driver::CheckFlag(uint32_t Flag)
{
    bool Result = false;

    if((m_pChannel->CSR & Flag) != 0)
    {
        Result = true;
    }

    return Result;
}

//-------------------------------------------------------------------------------------------------
//
//  Function:       EnableClock
//
//  Parameter(s):   None
//  Return:         None
//
//  Description:    Enable the associated DMA module clock
//-------------------------------------------------------------------------------------------------
void DMA_Driver::EnableClock(void)
{
    if(uintptr_t(m_pChannel) < GPDMA2_BASE)
    {
        SET_BIT(RCC->AHB1ENR, RCC_AHB1ENR_GPDMA1EN);
    }
    else
    {
        SET_BIT(RCC->AHB1ENR, RCC_AHB1ENR_GPDMA2EN);
    }
}

//-------------------------------------------------------------------------------------------------
//
//  Function:       SetMemoryIncrement
//
//  Parameter(s):   None
//  Return:         None
//
//  Description:    Perform emory increment
//
//  Notes(s) :      Only used this for transfer from or to a peripheral, mainly used for dummy TX
//                  or RX
//-------------------------------------------------------------------------------------------------
void DMA_Driver::SetMemoryIncrement(void)
{
    if(m_Direction == BSP_DMA_PERIPHERAL_TO_MEMORY)
    {
        SET_BIT(m_NodeInfo.LLRegisters[DMA_NODE_CTR1_IDX], DMA_CTR1_DINC);
    }
    else
    {
        SET_BIT(m_NodeInfo.LLRegisters[DMA_NODE_CTR1_IDX], DMA_CTR1_SINC);
    }
}

//-------------------------------------------------------------------------------------------------
//
//  Function:       SetNoMemoryIncrement
//
//  Parameter(s):   None
//  Return:         None
//
//  Description:    Do not perform emory increment
//
//  Notes(s) :      Only used this for transfer from or to a peripheral, mainly used for dummy TX
//                  or RX
//-------------------------------------------------------------------------------------------------
void DMA_Driver::SetNoMemoryIncrement(void)
{
    if(m_Direction == BSP_DMA_PERIPHERAL_TO_MEMORY)
    {
        CLEAR_BIT(m_NodeInfo.LLRegisters[DMA_NODE_CTR1_IDX], DMA_CTR1_DINC);
    }
    else
    {
        CLEAR_BIT(m_NodeInfo.LLRegisters[DMA_NODE_CTR1_IDX], DMA_CTR1_SINC);
    }
}

//-------------------------------------------------------------------------------------------------
