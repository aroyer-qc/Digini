
#include "lib_BSP_board.h"

//-------------------------------------------------------------------------------------------------
//
//  Function:       EXTI9_5_IRQHandler
//
//  Parameter(s):   None
//  Return:         None
//
//  Description:    Interrupt service routine for GPIOs 5-9
//
//  Note(s):
//
//-------------------------------------------------------------------------------------------------
void EXTI9_5_IRQHandler(void)
{
    if (EXTI->PR & GPIO_PIN_5) {
        IO_HandleExtiInterrupt(5);
    }
    if (EXTI->PR & GPIO_PIN_6) {
        IO_HandleExtiInterrupt(6);
    }
    if (EXTI->PR & GPIO_PIN_7) {
        IO_HandleExtiInterrupt(7);
    }
    if (EXTI->PR & GPIO_PIN_8) {
        IO_HandleExtiInterrupt(8);
    }
    if (EXTI->PR & GPIO_PIN_9) {
        IO_HandleExtiInterrupt(9);
    }
}

//-------------------------------------------------------------------------------------------------
//
//  Function:       EXTI15_10_IRQHandler
//
//  Parameter(s):   None
//  Return:         None
//
//  Description:    Interrupt service routine for GPIOs 10-15
//
//  Note(s):
//
//-------------------------------------------------------------------------------------------------
void EXTI15_10_IRQHandler(void)
{
    if (EXTI->PR & GPIO_PIN_10) {
        IO_HandleExtiInterrupt(10);
    }
    if (EXTI->PR & GPIO_PIN_11) {
        IO_HandleExtiInterrupt(11);
    }
    if (EXTI->PR & GPIO_PIN_12) {
        IO_HandleExtiInterrupt(12);
    }
    if (EXTI->PR & GPIO_PIN_13) {
        IO_HandleExtiInterrupt(13);
    }
    if (EXTI->PR & GPIO_PIN_14) {
        IO_HandleExtiInterrupt(14);
    }
    if (EXTI->PR & GPIO_PIN_15) {
        IO_HandleExtiInterrupt(15);
    }
}