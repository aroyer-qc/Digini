//-------------------------------------------------------------------------------------------------
//
//  File : lib_class_STM32H5_dma.cpp
//
//-------------------------------------------------------------------------------------------------
//
// Copyright(c) 2024 Alain Royer.
// Email: aroyer.qc@gmail.com
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software
// and associated documentation files (the "Software"), to deal in the Software without
// restriction, including without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or
// substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
// INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
// AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
// Include file(s)
//-------------------------------------------------------------------------------------------------

#define DMA_DRIVER_GLOBAL
#include "./lib_digini.h"
#undef  DMA_DRIVER_GLOBAL

//-------------------------------------------------------------------------------------------------
//
//  Function:       Initialize
//
//  Parameter(s):   DMA_Info_t*         pInfo
//  Return:         None
//
//  Description:    Initialize the DMA object
//
//  Note(s):        Add in direction support for M2M
//
//-------------------------------------------------------------------------------------------------
void DMA_Driver::Initialize(DMA_Info_t* pInfo)
{
    uint32_t Register = 0;

    m_pChannel       = pInfo->pChannel;
    m_Flag           = pInfo->Flag;
    m_IRQn_Channel   = pInfo->IRQn_Channel;
    m_Direction      = pInfo->Direction;
    m_PreempPrio     = pInfo->PreempPrio;
    EnableClock();

    m_pChannel->CCR  = pInfo->Priority;

    switch(pInfo->Direction) // See. "en.stm32h5-system-dma-overview-dmaovw.pdf" from ST Microelectronics, a copy exist in infra/docs
    {
        case DMA_PERIPHERAL_TO_MEMORY:  Register = (DMA_SOURCE_ALLOCATED_PORT1 | DMA_DESTINATION_ALLOCATED_PORT0); break;
        case DMA_MEMORY_TO_PERIPHERAL:  Register = (DMA_SOURCE_ALLOCATED_PORT0 | DMA_DESTINATION_ALLOCATED_PORT1); break;
        case DMA_MEMORY_TO_MEMORY:      Register = (DMA_SOURCE_ALLOCATED_PORT1 | DMA_DESTINATION_ALLOCATED_PORT1); break;
    }

    Register |= (pInfo->SrcAndDestIncrement                                  |
                 pInfo->SrcAndDestDataWidth                                  |
                 ((pInfo->SourceBurstLength - 1) << DMA_CTR1_DBL_1_Pos)      |
                 ((pInfo->DestinationBurstLength - 1) << DMA_CTR1_DBL_1_Pos));
    m_pChannel->CTR1 = Register;
    
    m_pChannel->CTR2 = (pInfo->Request              |
                        pInfo->BlockHardwareRequest |
                        pInfo->TransferEventMode    |
                        pInfo->Direction            |
                        pInfo->Mode);
}

//-------------------------------------------------------------------------------------------------
//
//  Function:       SetTransfer
//
//  Parameter(s):   Source
//                  Destination
//                  Length
//  Return:         None
//
//  Description:    Setup transfer from source to destination. according to configuration
//
//  Note(s):        Add in direction support for M2M
//
//-------------------------------------------------------------------------------------------------
void DMA_Driver::SetTransfer(void* pSource, void* pDestination, size_t Length)
{
    SetSource(pSource);
    SetDestination(pDestination);
    SetLength(Length);
}

//-------------------------------------------------------------------------------------------------
//
//  Function:       CheckFlag
//
//  Parameter(s):   Flag        Flag to check
//  Return:         bool        If true then flag is set.
//
//  Description:    Check flag for specific DMA stream.
//-------------------------------------------------------------------------------------------------
bool DMA_Driver::CheckFlag(uint32_t Flag)
{
    bool Result;

    if((m_pChannel->CSR & Flag) != 0)
    {
        Result = true;
    }

    return Result;
}

//-------------------------------------------------------------------------------------------------
//
//  Function:       EnableClock
//
//  Parameter(s):   None
//  Return:         None
//
//  Description:    Enable the associated DMA module clock
//-------------------------------------------------------------------------------------------------
void DMA_Driver::EnableClock(void)
{
    if(uintptr_t(m_pChannel) < GPDMA2_BASE)
    {
        SET_BIT(RCC->AHB1ENR, RCC_AHB1ENR_GPDMA1EN);
    }
    else
    {
        SET_BIT(RCC->AHB1ENR, RCC_AHB1ENR_GPDMA2EN);
    }
}

//-------------------------------------------------------------------------------------------------
//
//  Function:       SetMemoryIncrement
//
//  Parameter(s):   None
//  Return:         None
//
//  Description:    Perform emory increment
//
//  Notes(s) :      Only used this for transfer from or to a peripheral, mainly used for dummy TX
//                  or RX
//-------------------------------------------------------------------------------------------------
void DMA_Driver::SetMemoryIncrement(void)
{
    if(m_Direction == DMA_PERIPHERAL_TO_MEMORY)
    {
        SET_BIT(m_pChannel->CTR1, DMA_CTR1_DINC);
    }
    else
    {
        SET_BIT(m_pChannel->CTR1, DMA_CTR1_SINC);
    }
}

//-------------------------------------------------------------------------------------------------
//
//  Function:       SetNoMemoryIncrement
//
//  Parameter(s):   None
//  Return:         None
//
//  Description:    Do not perform emory increment
//
//  Notes(s) :      Only used this for transfer from or to a peripheral, mainly used for dummy TX
//                  or RX
//-------------------------------------------------------------------------------------------------
void DMA_Driver::SetNoMemoryIncrement(void)
{
    if(m_Direction == DMA_PERIPHERAL_TO_MEMORY)
    {
        CLEAR_BIT(m_pChannel->CTR1, DMA_CTR1_DINC);
    }
    else
    {
        CLEAR_BIT(m_pChannel->CTR1, DMA_CTR1_SINC);
    }
}

//-------------------------------------------------------------------------------------------------
