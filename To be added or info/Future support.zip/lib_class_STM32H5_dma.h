//-------------------------------------------------------------------------------------------------
//
//  File : lib_class_STM32H5_dma.h
//
//-------------------------------------------------------------------------------------------------
//
// Copyright(c) 2024 Alain Royer.
// Email: aroyer.qc@gmail.com
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software
// and associated documentation files (the "Software"), to deal in the Software without
// restriction, including without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all copies or
// substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
// INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
// AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//
//-------------------------------------------------------------------------------------------------

#pragma once

//-------------------------------------------------------------------------------------------------
// Define(s) and macro(s)
//-------------------------------------------------------------------------------------------------

// CCR Definition
//---------------
#define DMA_PRIORITY_LOW_PRIO_WEIGHT_LOW        0x0000000               // Low Priority level : Low weight
#define DMA_PRIORITY_LOW_PRIO_WEIGHT_MEDIUM     DMA_CCR_PRIO_0          // Low Priority level : Medium weight
#define DMA_PRIORITY_LOW_PRIO_WEIGHT_HIGH       DMA_CCR_PRIO_1          // Low Priority level : High weight
#define DMA_PRIORITY_HIGH_PRIO                  DMA_CCR_PRIO            // Low Priority level : High weight

// CTR2 Definition
//----------------

#define DMA_SOURCE_NO_INCREMENT                 0x00000000              // Source increment mode Disable
#define DMA_SOURCE_INCREMENT                    DMA_CTR1_SINC           // Source increment mode Enable

#define DMA_DESTINATION_NO_INCREMENT            0x00000000              // Destination increment mode Disable
#define DMA_DESTINATION_INCREMENT               DMA_CTR1_DINC           // Destination increment mode Enable

#define DMA_SOURCE_SIZE_8_BITS                  0x00000000              // Source data alignment : uint8_t
#define DMA_SOURCE_SIZE_16_BITS                 DMA_CTR1_SDW_LOG2_0     // Source data alignment : uint16_t
#define DMA_SOURCE_SIZE_32_BITS                 DMA_CTR1_SDW_LOG2_1     // Source data alignment : uint32_t

#define DMA_DESTINATION_SIZE_8_BITS             0x00000000              // Destination data alignment : uint8_t
#define DMA_DESTINATION_SIZE_16_BITS            DMA_CTR1_DDW_LOG2_0     // Destination data alignment : uint16_t
#define DMA_DESTINATION_SIZE_32_BITS            DMA_CTR1_DDW_LOG2_1     // Destination data alignment : uint32_t

// CTR2 Definition
//----------------
#define DMA_PERIPHERAL_TO_MEMORY                0x00000000U             // Peripheral to memory direction
#define DMA_MEMORY_TO_PERIPHERAL                DMA_CTR2_DREQ           // Memory to peripheral direction
#define DMA_MEMORY_TO_MEMORY                    DMA_CTR2_SWREQ          // Memory to memory direction
                                                                
#define DMA_BREQ_SINGLE_BURST                   0x00000000U             // Hardware request protocol at a single / burst level
#define DMA_BLOCK_HARDWARE_REQUEST              DMA_CTR2_BREQ           // Hardware request protocol at a block level
                                                                
#define DMA_MODE_NORMAL                         0x00000000              // Normal Mode
#define DMA_MODE_PERIPHERAL_FLOW_CTRL           DMA_CTR2_PFREQ          // Peripheral flow control mode

#define DMA_SOURCE_ALLOCATED_PORT0              0x00000000U 
#define DMA_SOURCE_ALLOCATED_PORT1              DMA_CTR1_SAP
#define DMA_DESTINATION_ALLOCATED_PORT0         0x00000000U
#define DMA_DESTINATION_ALLOCATED_PORT1         DMA_CTR1_DAP

#define DMA_TC_EVENT_BLOCK_TRANSFER             0x00000000U         // The TC event is generated at the end of each block and the HT event is generated at the half of each block
#define DMA_TC_EVENT_REPEATED_BLOCK_TRANSFER    DMA_CTR2_TCEM_0     // The TC event is generated at the end of the repeated block and the HT event is generated at the half of the repeated block

//-------------------------------------------------------------------------------------------------

#ifdef __cplusplus

//-------------------------------------------------------------------------------------------------
// Typedef(s)
//-------------------------------------------------------------------------------------------------

struct DMA_Info_t
{
    // Configuration
    uint32_t             Mode;
    uint32_t             Request;
    uint32_t             BlockHardwareRequest;
    uint32_t             Direction;
    uint32_t             SrcAndDestIncrement;
    uint32_t             SrcAndDestDataWidth;
    uint32_t             Priority;
    uint32_t             SourceBurstLength;
    uint32_t             DestinationBurstLength;
    uint32_t             TransferEventMode;
    DMA_Channel_TypeDef* pChannel;
    uint32_t             Flag;
    IRQn_Type            IRQn_Channel;
    uint8_t              PreempPrio;
};

//-------------------------------------------------------------------------------------------------
// class(s)
//-------------------------------------------------------------------------------------------------

class CallbackInterface
{
    public:

        virtual ~CallbackInterface() = default;
        virtual void CallbackFunction(int Type, void* pContext) = 0;
};

class DMA_Driver
{
    public:

        void        Initialize                              (DMA_Info_t* pInfo);
        void        SetTransfer                             (void* pSource, void* pDestination, size_t Length);
        bool        CheckFlag                               (uint32_t Flag);
        void        SetMemoryIncrement                      (void);
        void        SetNoMemoryIncrement                    (void);

        // Inline method
        void        Enable                                  (void)                              { SET_BIT(m_pChannel->CCR, DMA_CCR_EN);       }
        void        Disable                                 (void)                              { SET_BIT(m_pChannel->CCR, DMA_CCR_RESET);    }
        void        ClearFlag                               (void)                              { m_pChannel->CFCR = m_Flag;                  }
        void        SetSource                               (void* pSource)                     { m_pChannel->CSAR = uint32_t(pSource);       }  // Setup source for transfer
        void        SetDestination                          (void* pDestination)                { m_pChannel->CDAR = uint32_t(pDestination);  }  // Setup destination for transfer
        size_t      GetLength                               (void)                              { return size_t(m_pChannel->CBR1);            }
        void        SetLength                               (size_t Length)                     { m_pChannel->CBR1 = uint32_t(Length);        }
        void        SetFifoControl                          (uint32_t Control)                  { m_pChannel->CSR = Control;                  }  // very not sure about this
        void        RegisterCallback                        (CallbackInterface* pCallback)      { m_pCallback = pCallback;                    }
        void        EnableIRQ                               (void)                              { ISR_Init(m_IRQn_Channel, m_PreempPrio);     }  // Enable the IRQ DMA for the Channel
        void        EnableInterrupt                         (uint32_t Interrupt)                { SET_BIT(m_pChannel->CCR, Interrupt);        }
        void        DisableInterrupt                        (uint32_t Interrupt)                { CLEAR_BIT(m_pChannel->CCR, Interrupt);      }
        void        EnableTransmitCompleteInterrupt         (void)                              { SET_BIT(m_pChannel->CCR, DMA_CCR_TCIE);     }
        void        DisableTransmitCompleteInterrupt        (void)                              { CLEAR_BIT(m_pChannel->CCR, DMA_CCR_TCIE);   }
        void        EnableTransmitHalfCompleteInterrupt     (void)                              { SET_BIT(m_pChannel->CCR, DMA_CCR_HTIE);     }
        void        DisableTransmitHalfCompleteInterrupt    (void)                              { CLEAR_BIT(m_pChannel->CCR, DMA_CCR_HTIE);   }

    private:

        void        EnableClock                             (void);

        DMA_Channel_TypeDef*        m_pChannel;
        uint32_t                    m_Direction;
        IRQn_Type                   m_IRQn_Channel;
        uint8_t                     m_PreempPrio;
        uint32_t                    m_Flag;
        CallbackInterface*          m_pCallback;
};

//-------------------------------------------------------------------------------------------------

#endif // __cplusplus
